# R/41_zip_io.R — ZIP file I/O helpers

# ZIP creation is handled inline in server logic
# This module is reserved for future ZIP-related utilities
