# tests/testthat.R — Main test runner for ShinyDashAE

library(testthat)
library(shiny)

# Source the app code
test_check("ShinyDashAE")
